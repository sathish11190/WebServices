package test;

public class EG {

}

package chaining;

import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetCR extends BaseClass {
	@Test
	public static void getAllCRS() {
		Response response = RestAssured
				.given()
				.log().all()
				.get("change_request");
		json = response.jsonPath();
		List<String> listOfCRS = json.getList("result.sys_id");
		System.out.println("SIZE"+listOfCRS.size());
		int randomNumber=(int) (Math.random()*listOfCRS.size());
		System.out.println("RANDOM NUMBER"+randomNumber);
		sys_id = listOfCRS.get(randomNumber);
		System.out.println("sys_id : " + sys_id);



	}

}

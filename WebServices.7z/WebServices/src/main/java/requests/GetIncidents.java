package requests;

import java.util.List;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetIncidents {
	public static void main(String[] args) {
		RestAssured.authentication=RestAssured.basic("admin","Browny@10");//if the authentication is common 
		RestAssured.baseURI="https://dev58534.service-now.com/api/now/table";
		
		//Get all incidents
		Response response=RestAssured
				.given()
				.contentType(ContentType.JSON)
			//	.param("priority", "2")
				.body("{\r\n" + 
						"    \"result\": {\r\n" + 
						"        \"number\": \"CHG0030029\",\r\n" + 
						"        \"sys_id\": \"d746c53adb012300e6c2fe1b6896193b\",\r\n" + 
						"        \"priority\": \"2\"\r\n" + 
						"    }\r\n" + 
						"}")
				.post("change_request");//This incident will get appended to the base URI
		
		response.prettyPrint();
		
		JsonPath json = response.jsonPath();
		Object number = json.get("result.number");
		System.out.println(number);
		
	
				
	}

}

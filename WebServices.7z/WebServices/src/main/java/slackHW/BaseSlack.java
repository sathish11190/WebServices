package slackHW;

import org.testng.annotations.BeforeSuite;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class BaseSlack {
	public static String number;
	public static String description;
	public static String priority;
	public static String issueCreatedJira;
	public static JsonPath json;

	@BeforeSuite
	public void beforeSuite() {
		RestAssured.authentication = RestAssured.basic("admin", "Browny@10");// if the authentication is common
		RestAssured.baseURI = "https://dev58534.service-now.com/api/now/table/";
	}

}

package slackHW;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class PostAProblem  extends BaseSlack {

	@Test
	public static void postCR(/*String CR,String priority,String description*/) {
		Response response = RestAssured
				.given()
				.contentType(ContentType.JSON)
				// .param("priority", "2")
				//	.queryParam("sysparm_fields", "number,sys_id")
				.log().all()
				.body("{\r\n" + 
						"	\"description\": \"Created via RestAssured\",\r\n" + 
						"    \"number\": \"PRB0040003\",\r\n" + 
						"    \"priority\": \"5\"\r\n" + 
						"}")

				.post("problem");// This incident will get appended to the base URI

		// response.prettyPrint();

		json = response.jsonPath();
		System.out.println("****** RESULT ******* ");
		description = json.get("result.description");
		number = json.get("result.number");
		priority = json.get("result.priority");
		System.out.println("Desc : "+description);
		System.out.println("Number : "+number);
		System.out.println("Priority: "+priority);

		System.out.println(response.getStatusCode());
	}

	@DataProvider(name="fetchData",parallel=true,indices= {1})
	public Object[][] getData(){
		Object[][] data=new Object[2][2];
		data[0][0]="CHG0030040";
		data[0][1]="2";
		data[1][0]="CHG0030041";
		data[1][1]="2";
		return data;

	}


}

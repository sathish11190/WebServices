package chaining;

import java.util.List;
import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class PostCR extends BaseClass{

	@Test(dataProvider="fetchData")
	public static void postCR(String CR,String priority) {
		Response response = RestAssured
				.given()
				.contentType(ContentType.JSON)
				// .param("priority", "2")
			//	.queryParam("sysparm_fields", "number,sys_id")
				.log().all()
				.body("{\r\n" + "        \"number\": \""+CR+"\",\r\n" +
						"        \"priority\": \""+priority+"\"\r\n" + "}")

				.post("change_request");// This incident will get appended to the base URI

		// response.prettyPrint();

		json = response.jsonPath();
		System.out.println("DSFDSFSDFSDFD");
		Object number1 = json.get("result");
		System.out.println(number1);

		System.out.println(response.getStatusCode());
	}

	@DataProvider(name="fetchData",parallel=true,indices= {1})
	public Object[][] getData(){
		Object[][] data=new Object[2][2];
		data[0][0]="CHG0030040";
		data[0][1]="2";
		data[1][0]="CHG0030041";
		data[1][1]="2";
		return data;

	}
}

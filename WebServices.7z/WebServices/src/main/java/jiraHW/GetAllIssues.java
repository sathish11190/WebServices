package jiraHW;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.restassured.RestAssured;
import io.restassured.authentication.PreemptiveBasicAuthScheme;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetAllIssues {
	public static JsonPath json;
	public static String firstCreatedIssue;
	public static void authenticate() {
		PreemptiveBasicAuthScheme authScheme = new PreemptiveBasicAuthScheme();
		authScheme.setUserName("11190sathish@gmail.com");
		authScheme.setPassword("Browny@10");
		RestAssured.authentication = authScheme;
		//RestAssured.authentication = RestAssured.basic("11190sathish@gmail.com", "Browny@10");// if the authentication is common
		RestAssured.baseURI = "https://sathish11190.atlassian.net/rest/api/3/";
	}

	public static void getFirstCreatedIssue() {
		Response response = RestAssured
				.given()
				.log().all()
				.queryParam("jql", "project=WEB")
				.get("search");

		//System.out.println(response.prettyPrint());
		json = response.jsonPath();
		List<Object> listOfIssues = json.getList("issues");
		//System.out.println("Issues Count : " +listOfIssues.size());

		List<String> issuesCreated = json.getList("issues.fields.created");
		List<String> desc = json.getList("issues.fields.description");
		List<String> issues = json.getList("issues.key");
		HashMap<String, String> m1 =new HashMap<String, String>();
		for(int i=0;i<issues.size();i++) {
			m1.put(issues.get(i), issuesCreated.get(i));
		}
		//System.out.println(m1);
		Collections.sort(issuesCreated);
		for (Object iss: issuesCreated) {
			System.out.println(iss);			
		}

		for(Map.Entry<String, String > e1:m1.entrySet()) {
			if(e1.getValue().equals(issuesCreated.get(0))) {
				System.out.println("FIRST CREATED ISSUE"+e1.getKey());
				firstCreatedIssue=e1.getKey();
			}
		}
		//System.out.println("ISSUE SIZE"+issues.size());
		//System.out.println("ISSUE CREATED"+issuesCreated.size());

		System.out.println(response.getStatusCode());


	}

	public static void deleteFirstCreatedIssue() {
		Response response = RestAssured
				.given()
				.pathParam("key", firstCreatedIssue)
				.log().all()
				.delete("issue/{key}");
		System.out.println("STATUS CODE  : "+response.statusCode());

	}


	public static void postAnIssueWithDesc() {
		Response response = RestAssured
				.given()
				.contentType(ContentType.JSON)
				// .param("priority", "2")
				.queryParam("sysparm_fields", "description")
				.log().all()
				.body("{\r\n" + 
						"	\"fields\":{\r\n" + 
						"		\"project\":{\r\n" + 
						"			\"id\": \"10000\"\r\n" + 
						"		},\r\n" + 
						"		\"summary\": \"Automated from Rest Assured\",\r\n" + 
						"		\"issuetype\":{\r\n" + 
						"			\"id\": \"10002\",\r\n" + 
						"			 \"description\": \"LOLOLOLOLOLOLOL.\"\r\n" + 
						"		}\r\n" + 
						"	}\r\n" + 
						"}")

				.post("issue");// This incident will get appended to the base URI

		//response.prettyPrint();


		System.out.println(response.getStatusCode());
	}

	public static void main(String[] args) {

		authenticate();
		getFirstCreatedIssue();
		deleteFirstCreatedIssue();
		postAnIssueWithDesc();
	}

}

package requests;

import java.util.List;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class DeleteCR {
	public static JsonPath json;
	
	public static void authenticate() {
		RestAssured.authentication = RestAssured.basic("admin", "Browny@10");// if the authentication is common
		RestAssured.baseURI = "https://dev58534.service-now.com/api/now/table/";
	}

	public static void deleteCR() {
		Response response = RestAssured
				.given()
				.pathParam("sys_id", "fc2a9136db412300e6c2fe1b68961927")
				.log().all()
				.delete("change_request/{sys_id}");
			System.out.println("STATUS CODE  : "+response.statusCode());

	}



	public static void main(String[] args) {

		authenticate();
		// delete
		deleteCR();
	}

}

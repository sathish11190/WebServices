package requests;

import java.util.List;
import java.util.Map;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CreateChangeReq {
	public static JsonPath json;

	public static void getTotalNumberOfCR() {
		Response response = RestAssured.given().get("change_request");
		json = response.jsonPath();
		List<Object> listOfCRS = json.getList("result.number");
		System.out.println("CR Count : " + listOfCRS.size());

	}

	public static void postCR() {
		Response response = RestAssured
				.given()
				.contentType(ContentType.JSON)
				// .param("priority", "2")
				.queryParam("sysparm_fields", "number,sys_id")
				.log().all()
				.body("{\r\n" + "        \"number\": \"CHG0030030\",\r\n" +
								"        \"priority\": \"2\"\r\n" + "}")
				
				.post("change_request");// This incident will get appended to the base URI

		// response.prettyPrint();
		Map<String, String> cookies = response.getCookies();
		for (Map.Entry<String, String> e1 : cookies.entrySet()) {
			System.out.println(e1);
			
		}
		
		json = response.jsonPath();
		Object number1 = json.get("result.number");
		System.out.println(number1);

		System.out.println(response.getStatusCode());
	}

	public static void main(String[] args) {

		RestAssured.authentication = RestAssured.basic("admin", "Browny@10");// if the authentication is common
		RestAssured.baseURI = "https://dev58534.service-now.com/api/now/table";
		// get all CR's before posting
		getTotalNumberOfCR();
		// Create a CR
		postCR();
		// get CR count
		getTotalNumberOfCR();
	}

}

package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteCR extends BaseClass{	
	@Test(dependsOnMethods="chaining.GetCR.getAllCRS")
	public static void deleteCR() {
		Response response = RestAssured
				.given()
				.pathParam("sys_id", sys_id)
				.log().all()
				.delete("change_request/{sys_id}");
			System.out.println("STATUS CODE  : "+response.statusCode());

	}
}

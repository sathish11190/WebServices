package slackHW;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.authentication.PreemptiveBasicAuthScheme;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class PostIssueJira  extends BaseSlack{

	public static String firstCreatedIssue;
	public void authenticate() {
		PreemptiveBasicAuthScheme authScheme = new PreemptiveBasicAuthScheme();
		authScheme.setUserName("11190sathish@gmail.com");
		authScheme.setPassword("Browny@10");
		RestAssured.authentication = authScheme;
		//RestAssured.authentication = RestAssured.basic("11190sathish@gmail.com", "Browny@10");// if the authentication is common
		RestAssured.baseURI = "https://sathish11190.atlassian.net/rest/api/3/";
	}

	public void postAnIssueWithDesc() {
		Response response = RestAssured
				.given()
				.contentType(ContentType.JSON)
				// .param("priority", "2")
				.queryParam("sysparm_fields", "description")
				.log().all()
				.body("{\r\n" + 
						"	\"fields\":{\r\n" + 
						"		\"project\":{\r\n" + 
						"			\"id\": \"10000\"\r\n" + 
						"		},\r\n" + 
						"		\"summary\": \"Created from Postman\",\r\n" + 
						"		\"issuetype\":{\r\n" + 
						"			\"id\": \"10002\",\r\n" + 
						"			 \"description\": \"LOLOLOLOLOLOLOL.\"\r\n" + 
						"		}\r\n" + 
						"	}\r\n" + 
						"}")

				.post("issue");// This incident will get appended to the base URI

	//	response.prettyPrint();
		json = response.jsonPath();
		issueCreatedJira = json.get("id");
		System.out.println("ID : " +issueCreatedJira );

		System.out.println(response.getStatusCode());
	}
	
	
	public static void getCreatedIssueFromJira() {
		Response response = RestAssured
				.given()
				.contentType(ContentType.JSON)
				.log().all()
				.get("issue/"+issueCreatedJira);

	//	System.out.println("dsdds"+"//n"+response.prettyPrint());
		json = response.jsonPath();
		String listOfIssues = json.get("description");
		System.out.println("Desc : " +listOfIssues);
		System.out.println(response.getStatusCode());


	}
	@Test
	public void main() {

		authenticate();
		postAnIssueWithDesc();
		getCreatedIssueFromJira();
	}

}
